
using System;

namespace Segmage.Models
{
    public abstract class BaseEvent<TUserIdType>
    {
        public Guid SessionId { get; set; }
        public TUserIdType UserId { get; set; }
    }
}
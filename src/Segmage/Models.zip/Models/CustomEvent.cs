namespace Segmage.Models
{
	public class CustomEvent<TUserIdType> : BaseEvent<TUserIdType>
	{
		public string Data { get; set; }
	}
}
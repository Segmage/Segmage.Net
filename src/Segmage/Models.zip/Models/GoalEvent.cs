namespace Segmage.Models
{
	public class GoalEvent<TUserIdType> : BaseEvent<TUserIdType>
	{
		public decimal? Value { get; set; }
	}
}
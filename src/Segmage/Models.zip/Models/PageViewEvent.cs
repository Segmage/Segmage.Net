namespace Segmage.Models
{
    public class PageViewEvent<TUserIdType> : BaseEvent<TUserIdType>
	{
        public string Referer { get; set; }
        public string Title { get; set; }
        public string Url { get; set; }
    }
}
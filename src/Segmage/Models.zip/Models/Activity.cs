﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Segmage.Models
{
	public abstract class Activity<TIdType, TUserIdType>
	{
		public TIdType Id { get; set; }
		public string Status { get; set; }
		public DateTime PlannedDate { get; set; }
		public DateTime? CompletionDate { get; set; }
		public TUserIdType UserId { get; set; }
		public string Title { get; set; }
		public string OpportunityId { get; set; }
		public string OfferId { get; set; }
	}
}

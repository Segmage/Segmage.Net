﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Segmage.Models
{
	public class BasketItem<TIdType, TBasketIdType, TProductIdType> : ProductItem<TProductIdType>
	{
        public TIdType Id { get; set; }
        public TBasketIdType BasketId { get; set; }
	}
}

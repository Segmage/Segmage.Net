namespace Segmage.Models
{
    public class LogoutEvent<TUserIdType> : BaseEvent<TUserIdType>
	{
    }
}
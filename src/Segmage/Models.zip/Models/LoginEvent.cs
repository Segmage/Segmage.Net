namespace Segmage.Models
{
    public class LoginEvent<TUserIdType> : BaseEvent<TUserIdType>
	{
    }
}